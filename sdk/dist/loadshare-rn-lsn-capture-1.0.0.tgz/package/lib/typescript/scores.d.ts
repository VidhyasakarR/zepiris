import type { LsnCheck, LsnScoreOptions, LsnScores } from './types';
/**
 * The raw /v1/checkpoint/score JSON, flattened (same mapping as the Flutter
 * SDK's LsnScores). Pure: never throws, missing fields become null.
 */
export declare function toScores(raw: Record<string, unknown>): LsnScores;
export declare const ALL_CHECKS: LsnCheck[];
export declare const DEFAULT_TIMEOUT_MS = 40000;
/**
 * Same rules as the native side (and the Flutter SDK's api.dart), checked in JS
 * too so `start()` fails before the rider is sent to the camera.
 * Throws an LsnError with code 'invalid_config'.
 */
export declare function validateScoreOptions(opts: Omit<LsnScoreOptions, 'faceCheckPath' | 'faceCheckS3'>): void;
//# sourceMappingURL=scores.d.ts.map