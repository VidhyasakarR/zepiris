# LSN Capture SDK

The Loadshare checkpoint selfie as a native Android flow in a Flutter package. It runs the camera, the oval guide, live checks and a liveness challenge, and captures a photo. It then runs the server's photo quality check, submits to `/v1/checkpoint/verify`, and shows the result.

## Use it

```yaml
dependencies:
  lsn_capture_sdk:
    path: ../lsn_capture_sdk   # wherever you put the folder (see ../README.md for git / zip)
```

```dart
import 'package:lsn_capture_sdk/lsn_capture_sdk.dart';

// 1. Early, for example when the screen before the capture shows:
LsnCapture.warmUp(); // face model ready + CameraX initialised

// 2. The app must hold the CAMERA permission, then:
final r = await LsnCapture.start(context, const LsnCaptureConfig(
  apiBase: 'https://3-108-193-187.sslip.io',
  checks: ['face_match', 'dress_color', 'logo'],
  sourceSelfieS3: 'https://bucket.s3.amazonaws.com/rider.jpg', // or sourceSelfieB64
  challenge: 'blink', // blink | turn | random | none
));
if (r != null) {
  r.isCleared;   // the server's decision
  r.photoJpeg;   // the exact photo that was sent
  r.stats;       // firstDetectionMs, detectMsAvg, captureMs, frames, flashed
}
```

- `submit: false` returns the photo without calling `/v1/checkpoint/verify`, so the host can submit it itself.
- `qualityCheck: false` skips `/v1/quality/check`.

## How it works

| Part | What it does |
|---|---|
| `CaptureActivity.kt` | CameraX with three use cases, each at its own resolution. **Preview** and **photo** are 4:3, the camera's native shape and the framing of the phone's own camera app. The photo is 1920×1440 (portrait 1440×1920). **Analysis** is 640×480, in the same 4:3 field of view. The preview is fitted, not cropped, so the rider sees exactly what the photo contains. |
| `FaceEngine.kt` | ML Kit face detection in fast mode, with eye-open classification and tracking. It comes from Google Play Services, so the APK only grows by about 0.8 MB. `warmUp` asks Play Services to install the model if it's missing, runs one dummy frame, and initialises CameraX. |
| `Checks.kt` | The live checks, in order: light, exactly one face, size, centred, enough T-shirt in frame, head frontal, eyes open, holding still. Also the liveness challenge. The T-shirt rule is the server's own (`capture_quality.py`): at least 35% of the region from the chin down to 3 face heights must be in frame. Covered by JUnit tests in `src/test`. |
| `capture_screen.dart` | Review, quality warnings, Retake or Submit, and the result. |

Liveness:
- **Blink:** measured against the rider's own open-eye level, so glasses and dim light work. A wink or a still photo never passes.
- **Turn:** turn more than 20° to one side, then come back within 8°.
- **Face swaps:** a second face, or 1.2 s with no face, restarts the challenge.
- **Low light:** the screen turns white for 0.8 s while the photo is taken, at full brightness.

## Numbers

Measured on a Redmi 2312FRAFDI (Android 15), arm64 release APK:

| Build | APK |
|---|---|
| App without the SDK | 17.95 MB |
| With this SDK (CameraX + ML Kit via Play Services) | **18.78 MB (+0.82 MB; +0.90 MB on armeabi-v7a)** |
| The SDK's own compiled code (`.aar`) | 42 KB |
| Earlier Dart version with the bundled ML Kit model | 32.0 MB |

## Tests

```bash
cd <your app>/android && ./gradlew :lsn_capture_sdk:testReleaseUnitTest   # e.g. mobile/lsn_checkpoint
```

Face measurements go to logcat (tag `LsnCapture`) when the host builds with `--dart-define=LSN_SDK_DEBUG=true`.

## Limits

- **Android only.** An iOS version would be the same design in Swift, with AVFoundation and ML Kit for iOS.
- **Needs Google Play Services** for the face model. Without it, the flow ends with `face_check_unavailable` after 10 s; use the web flow there.
- **Liveness is checked on the phone only.** `challengePassed` is returned to the app, but the server doesn't receive it. The server's own passive liveness check still decides.
