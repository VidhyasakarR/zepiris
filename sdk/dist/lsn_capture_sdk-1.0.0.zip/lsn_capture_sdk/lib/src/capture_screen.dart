import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'api.dart';

const _bg = Color(0xFF05080F);
const _pass = Color(0xFF0F8A5F);
const _fail = Color(0xFFC43B2F);
const _muted = Color(0xFF26324D);

/// Native side (Android): warm-up and the capture screen (CameraX + ML Kit).
class NativeCapture {
  static const _ch = MethodChannel('lsn_capture_sdk');

  static Future<Map<String, dynamic>> warmUp() async =>
      Map<String, dynamic>.from(await _ch.invokeMethod<Map>('warmUp') ?? {});

  /// The captured photo file and on-device stats, or null if the rider backed out.
  static Future<({String path, Map<String, dynamic> stats})?> capture(
    String challenge, {
    bool debug = false,
  }) async {
    final r = await _ch.invokeMethod<Map>('capture', {
      'challenge': challenge,
      'debug': debug,
    });
    if (r == null || r['path'] == null) return null;
    var stats = <String, dynamic>{};
    try {
      stats = jsonDecode(r['stats'] as String) as Map<String, dynamic>;
    } catch (_) {}
    return (path: r['path'] as String, stats: stats);
  }
}

enum _Stage { capturing, review, submitting, result, error }

/// Runs the native camera, then review → quality warnings → submit → result.
class CaptureScreen extends StatefulWidget {
  const CaptureScreen({
    super.key,
    required this.config,
    this.accent = const Color(0xFF1F5FD6),
    this.debug = false,
  });
  final LsnCaptureConfig config;
  final Color accent;
  final bool debug;

  @override
  State<CaptureScreen> createState() => _CaptureScreenState();
}

class _CaptureScreenState extends State<CaptureScreen> {
  late final _api = CheckpointApi(widget.config);
  _Stage _stage = _Stage.capturing;
  Uint8List? _photo;
  Map<String, dynamic> _stats = {};
  Map<String, dynamic>? _quality, _checkpoint;
  String? _error;
  int _attempt = 0; // late replies for an older photo are dropped
  bool _done = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _shoot());
  }

  @override
  void dispose() {
    _api.close();
    super.dispose();
  }

  Future<void> _shoot() async {
    final mine = ++_attempt;
    setState(() {
      _stage = _Stage.capturing;
      _photo = null;
      _quality = null;
      _checkpoint = null;
      _error = null;
    });
    try {
      final shot = await NativeCapture.capture(
        widget.config.challenge,
        debug: widget.debug,
      );
      if (!mounted || mine != _attempt) return;
      if (shot == null) {
        return Navigator.of(context).pop(); // backed out of the camera
      }
      final file = File(shot.path);
      final bytes = await file.readAsBytes();
      file.delete().ignore();
      if (!mounted || mine != _attempt) return;
      setState(() {
        _photo = bytes;
        _stats = shot.stats;
        _stage = _Stage.review;
      });
      if (widget.config.qualityCheck) {
        final q = await _api.quality(bytes);
        if (mounted && mine == _attempt) setState(() => _quality = q);
      }
    } on PlatformException catch (e) {
      if (!mounted) return;
      setState(() {
        _stage = _Stage.error;
        _error = switch (e.code) {
          'no_permission' =>
            'Camera permission is needed. Allow it in Settings.',
          'face_check_unavailable' =>
            'Face check could not start on this phone (Google Play Services is needed). Use the web flow.',
          _ => 'Camera unavailable (${e.message ?? e.code})',
        };
      });
    }
  }

  Future<void> _submit() async {
    final photo = _photo;
    if (photo == null || _stage == _Stage.submitting) return;
    if (!widget.config.submit) return _finish();
    final mine = _attempt;
    setState(() {
      _stage = _Stage.submitting;
      _error = null;
    });
    try {
      final r = await _api.verify(photo);
      if (mounted && mine == _attempt) {
        setState(() {
          _checkpoint = r;
          _stage = _Stage.result;
        });
      }
    } on ApiError catch (e) {
      if (mounted && mine == _attempt) {
        setState(() {
          _error = e.message;
          _stage = _Stage.review;
        });
      }
    }
  }

  void _finish() {
    if (_done) return; // double tap on Done
    _done = true;
    final photo = _photo;
    Navigator.of(context).pop(
      photo == null
          ? null
          : LsnCaptureResult(
              photoJpeg: photo,
              challenge:
                  _stats['challenge'] as String? ?? widget.config.challenge,
              challengePassed: _stats['challengePassed'] as bool? ?? false,
              quality: _quality,
              checkpoint: _checkpoint,
              stats: _stats,
            ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final warnings = (_quality?['warnings'] as List?)?.cast<Map>() ?? const [];
    return PopScope(
      // never lose a submit in flight; after a result, back = Done (keeps it)
      canPop: _stage != _Stage.submitting && _stage != _Stage.result,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && _stage == _Stage.result) _finish();
      },
      child: Scaffold(
        backgroundColor: _bg,
        body: Stack(
          fit: StackFit.expand,
          children: [
            if (_photo != null)
              Center(
                child: Image.memory(
                  _photo!,
                  fit: BoxFit.contain,
                  gaplessPlayback: true,
                ),
              )
            else if (_stage == _Stage.capturing)
              const Center(child: CircularProgressIndicator()),
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(6, 6, 16, 0),
                  child: Row(
                    children: [
                      IconButton.filledTonal(
                        onPressed: _stage == _Stage.submitting
                            ? null
                            : _stage == _Stage.result
                            ? _finish
                            : () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.arrow_back),
                      ),
                      const SizedBox(width: 10),
                      const Text(
                        'Checkpoint selfie',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: SafeArea(
                child: Container(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Color(0x0005080F), Color(0xE605080F)],
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: _dock(warnings),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _dock(List<Map> warnings) {
    Widget banner(String t, {Color? color}) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: color ?? const Color(0xCC0F1728),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Text(
        t,
        textAlign: TextAlign.center,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 15,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
    ButtonStyle big(Color c) => FilledButton.styleFrom(
      backgroundColor: c,
      foregroundColor: Colors.white,
      disabledBackgroundColor: _muted,
      disabledForegroundColor: Colors.white70,
      minimumSize: const Size.fromHeight(54),
      textStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
    );

    switch (_stage) {
      case _Stage.capturing:
        return [banner('Opening the camera…')];
      case _Stage.error:
        return [
          banner(_error ?? 'Something went wrong', color: _fail),
          FilledButton(
            style: big(widget.accent),
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Back'),
          ),
        ];
      case _Stage.review:
      case _Stage.submitting:
        final checking =
            widget.config.qualityCheck &&
            _quality == null &&
            _stage == _Stage.review;
        return [
          if (checking) banner('Checking the photo…'),
          if (warnings.isNotEmpty)
            banner(
              'Retake recommended:\n${warnings.map((w) => '• ${w['message']}').join('\n')}',
              color: const Color(0xE63A1512),
            ),
          if (_quality != null && warnings.isEmpty)
            banner('Face and T-shirt clear', color: _pass),
          if (_error != null) banner(_error!, color: _fail),
          Row(
            children: [
              Expanded(
                child: FilledButton(
                  style: big(warnings.isNotEmpty ? widget.accent : _muted),
                  onPressed: _stage == _Stage.submitting ? null : _shoot,
                  child: const Text('Retake'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton(
                  style: big(warnings.isEmpty ? widget.accent : _muted),
                  onPressed: _stage == _Stage.submitting ? null : _submit,
                  child: Text(
                    _stage == _Stage.submitting
                        ? 'Checking…'
                        : !widget.config.submit
                        ? 'Use photo'
                        : warnings.isEmpty
                        ? 'Submit'
                        : 'Submit anyway',
                  ),
                ),
              ),
            ],
          ),
        ];
      case _Stage.result:
        final r = _checkpoint ?? {};
        final checks = (r['checks'] as Map?)?.cast<String, dynamic>() ?? {};
        final cleared = r['isCleared'] == true;
        const label = {
          'face_match': 'Face match',
          'dress_color': 'Dress colour',
          'logo': 'Logo',
        };
        return [
          banner(
            cleared ? '✓ Cleared' : '✕ Not cleared',
            color: cleared ? _pass : _fail,
          ),
          for (final e in checks.entries)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      label[e.key] ?? e.key,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  Text(
                    '${(e.value['score'] as num?)?.toStringAsFixed(2) ?? '—'} / ${(e.value['threshold'] as num?)?.toStringAsFixed(2) ?? '—'}  ',
                    style: const TextStyle(
                      color: Colors.white70,
                      fontFeatures: [FontFeature.tabularFigures()],
                    ),
                  ),
                  Text(
                    e.value['passed'] == true ? 'PASS' : 'FAIL',
                    style: TextStyle(
                      color: e.value['passed'] == true
                          ? const Color(0xFF5FD39A)
                          : const Color(0xFFFF8B7A),
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: FilledButton(
                  style: big(_muted),
                  onPressed: _shoot,
                  child: const Text('Retake'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton(
                  style: big(widget.accent),
                  onPressed: _finish,
                  child: const Text('Done'),
                ),
              ),
            ],
          ),
        ];
    }
  }
}
