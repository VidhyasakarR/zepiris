import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

/// What the host app asks the capture flow to do.
class LsnCaptureConfig {
  const LsnCaptureConfig({
    required this.apiBase,
    this.checks = const ['face_match', 'dress_color', 'logo'],
    this.sourceSelfieS3,
    this.sourceSelfieB64,
    this.challenge = 'blink',
    this.submit = true,
    this.qualityCheck = true,
  });

  /// Server root, e.g. https://3-108-193-187.sslip.io (no trailing slash needed).
  final String apiBase;

  /// Any of face_match, dress_color, logo.
  final List<String> checks;

  /// Enrolled selfie for face_match: an S3/HTTP link or base64 JPEG.
  final String? sourceSelfieS3, sourceSelfieB64;

  /// Liveness challenge before Capture unlocks: blink | turn | random | none.
  final String challenge;

  /// true: POST the photo to /v1/checkpoint/verify and show the result.
  /// false: return the photo only (the host submits it itself).
  final bool submit;

  /// Run the server's capture quality check (blur, light, T-shirt visible)
  /// right after capture and show its warnings.
  final bool qualityCheck;

  String get base => apiBase.trim().replaceAll(RegExp(r'/+$'), '');
}

/// What the flow hands back. `null` from [LsnCapture.start] = the rider backed out.
class LsnCaptureResult {
  const LsnCaptureResult({
    required this.photoJpeg,
    required this.challenge,
    required this.challengePassed,
    this.quality,
    this.checkpoint,
    this.stats = const {},
  });

  /// The exact photo that was (or would be) sent to the backend.
  final Uint8List photoJpeg;
  final String challenge;
  final bool challengePassed;

  /// /v1/quality/check response ({ok, warnings, face, shirt}) or null.
  final Map<String, dynamic>? quality;

  /// /v1/checkpoint/verify response ({isCleared, checks, ...}) or null.
  final Map<String, dynamic>? checkpoint;

  /// On-device timings: firstDetectionMs, detectMsAvg, captureMs, frames, flashed.
  final Map<String, dynamic> stats;

  bool? get isCleared => checkpoint?['isCleared'] as bool?;
}

class ApiError implements Exception {
  ApiError(this.message, [this.status]);
  final String message;
  final int? status;
  @override
  String toString() => message;
}

/// The two backend calls the flow makes. A non-browser user agent keeps
/// ngrok's free-tier warning page out of the way during testing.
class CheckpointApi {
  CheckpointApi(this.config, {http.Client? client})
    : _http = client ?? http.Client();
  final LsnCaptureConfig config;
  final http.Client _http;
  static const _headers = {
    'Content-Type': 'application/json',
    'User-Agent': 'LSNCaptureSDK/1.0',
  };

  Future<Map<String, dynamic>> _post(
    String path,
    Map<String, dynamic> body,
    Duration timeout,
  ) async {
    final http.Response r;
    try {
      r = await _http
          .post(
            Uri.parse('${config.base}$path'),
            headers: _headers,
            body: jsonEncode(body),
          )
          .timeout(timeout);
    } on TimeoutException {
      throw ApiError(
        'The server took too long — check the connection and try again',
      );
    } catch (_) {
      throw ApiError(
        'Could not reach the server — check the connection and try again',
      );
    }
    Object? d;
    try {
      d = jsonDecode(r.body);
    } catch (_) {}
    if (r.statusCode >= 400) {
      final det = d is Map ? d['detail'] : null;
      final why = switch (det) {
        String s => s,
        Map m => m['message'] ?? jsonEncode(m),
        List l when l.isNotEmpty =>
          (l.first is Map ? (l.first as Map)['msg'] : null) ??
              'invalid request', // FastAPI 422
        _ => r.reasonPhrase ?? 'error',
      };
      throw ApiError('Server error ${r.statusCode}: $why', r.statusCode);
    }
    if (d is! Map<String, dynamic>) {
      // e.g. a proxy's HTML page: never read that as "Not cleared"
      throw ApiError(
        'The server sent an unexpected reply (${r.statusCode})',
        r.statusCode,
      );
    }
    return d;
  }

  void close() => _http.close();

  /// Blur / light / T-shirt warnings for a captured photo (null if unreachable:
  /// the check is advisory and must never block a capture).
  Future<Map<String, dynamic>?> quality(Uint8List jpeg) async {
    try {
      return await _post('/v1/quality/check', {
        'image_b64': base64Encode(jpeg),
      }, const Duration(seconds: 8));
    } catch (_) {
      return null;
    }
  }

  Future<Map<String, dynamic>> verify(Uint8List jpeg) =>
      _post('/v1/checkpoint/verify', {
        'face_check_b64': base64Encode(jpeg),
        'checks': config.checks,
        if (config.sourceSelfieS3 != null && config.sourceSelfieS3!.isNotEmpty)
          'source_selfie_s3': config.sourceSelfieS3,
        if (config.sourceSelfieB64 != null &&
            config.sourceSelfieB64!.isNotEmpty)
          'source_selfie_b64': config.sourceSelfieB64,
      }, const Duration(seconds: 40));
}
