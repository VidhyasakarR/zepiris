## 1.0.0

- Native Android capture screen: CameraX preview and 4:3 photo (1440×1920), with 640×480 analysis frames going straight to ML Kit face detection from Play Services.
- Live checks: light, one face, size, centring, T-shirt in frame (the server's capture-quality rule), head frontal, eyes open, holding still.
- Liveness challenge: blink (judged against the rider's own open-eye level) or head turn, restarted when the face changes.
- Low-light screen flash at full brightness.
- Review screen: server quality warnings, Retake or Submit, the checkpoint result.
- `LsnCapture.warmUp()` / `LsnCapture.start()` API; `submit: false` returns the photo only.
