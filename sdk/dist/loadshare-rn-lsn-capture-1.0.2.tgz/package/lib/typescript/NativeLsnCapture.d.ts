import type { LsnCaptureResult, LsnWarmUpResult } from './types';
/**
 * The `LsnCapture` legacy native module (LsnCaptureModule.kt). It works under
 * the new architecture through the interop layer. Android only.
 */
export interface NativeLsnCaptureSpec {
    warmUp(): Promise<LsnWarmUpResult>;
    capture(opts: Record<string, unknown>): Promise<LsnCaptureResult>;
    score(opts: Record<string, unknown>): Promise<Record<string, unknown>>;
}
/** null on iOS / web, or when the native module is not linked. */
export declare const NativeLsnCapture: NativeLsnCaptureSpec | null;
//# sourceMappingURL=NativeLsnCapture.d.ts.map