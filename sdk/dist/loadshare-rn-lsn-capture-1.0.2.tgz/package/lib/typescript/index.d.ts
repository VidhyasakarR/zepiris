import type { LsnCaptureOptions, LsnCaptureResult, LsnScoreOptions, LsnScores, LsnStartOptions, LsnStartResult, LsnWarmUpResult } from './types';
export * from './types';
export { toScores } from './scores';
/** true on Android when the native module is linked. Never throws. */
export declare function isSupported(): boolean;
/**
 * Load the face model and CameraX ahead of time (call when the screen before
 * the capture shows). Resolves with modelReady=false instead of rejecting when
 * the model is not there; can take long on first run (model download), so
 * don't await it on the critical path.
 */
export declare function warmUp(): Promise<LsnWarmUpResult>;
/** Open the native camera screen; resolves with the JPEG path. Rejects 'cancelled' if the rider backs out. */
export declare function capture(opts?: LsnCaptureOptions): Promise<LsnCaptureResult>;
/** POST {apiBase}/v1/checkpoint/score. The file is read and base64-encoded natively. */
export declare function score(opts: LsnScoreOptions): Promise<LsnScores>;
/** capture() then score() on the captured photo. Score options are validated before the camera opens. */
export declare function start(opts: LsnStartOptions): Promise<LsnStartResult>;
//# sourceMappingURL=index.d.ts.map