import type { LsnError, LsnErrorCode } from './types';
export declare const LSN_ERROR_CODES: readonly LsnErrorCode[];
export declare function lsnError(code: LsnErrorCode, message?: string): LsnError;
/**
 * A native promise rejection (or anything thrown) → an Error whose `.code` is
 * an LsnErrorCode. An unknown code becomes `fallback`; the original code is
 * kept in `.nativeCode` and the original message is never replaced.
 */
export declare function toLsnError(e: unknown, fallback: LsnErrorCode): LsnError;
//# sourceMappingURL=errors.d.ts.map