import type { LsnCheck, LsnScoreOptions, LsnScores } from './types';
/**
 * The raw /v1/checkpoint/score JSON, flattened (same mapping as the Flutter
 * SDK's LsnScores). Pure: never throws; missing or wrongly-typed fields
 * (strings for numbers, NaN, arrays for objects) become null.
 */
export declare function toScores(raw: unknown): LsnScores;
export declare const ALL_CHECKS: LsnCheck[];
export declare const DEFAULT_TIMEOUT_MS = 40000;
/** Keep in sync with ScoreRequest in android/.../ScoreClient.kt. */
export declare const MAX_TIMEOUT_MS = 600000;
export declare const MAX_SELFIE_B64_CHARS: number;
/**
 * Same rules as the native side (ScoreRequest.validate, itself the Flutter
 * SDK's api.dart), checked in JS too so errors surface before the bridge and
 * `start()` fails before the rider is sent to the camera.
 * `requirePhoto: false` skips the faceCheckPath / faceCheckS3 rule (start()).
 * Throws an LsnError with code 'invalid_config'.
 */
export declare function validateScoreOptions(opts: Partial<LsnScoreOptions> | null | undefined, requirePhoto?: boolean): void;
//# sourceMappingURL=scores.d.ts.map